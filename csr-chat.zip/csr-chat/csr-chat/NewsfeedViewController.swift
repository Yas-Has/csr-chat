//
//  NewsfeedViewController.swift
//  csr-chat
//
//  Created by Brandon Sugarman on 5/23/19.
//  Copyright © 2019 Brandon Sugarman. All rights reserved.
//

import UIKit
import Firebase

class NewsfeedViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var newsfeed: UITableView!
    
    var posts: Array<String>!
    
    var ref: DatabaseReference!
    
    @IBAction func signOut(_ sender: UIButton) {
        CSRMethods.app.changeScreens(id:"home")
        
    }
    
    
    
    
    @IBAction func addPost(_ sender: UIButton) {
        CSRMethods.app.changeScreens(id: "writepost")
    }
    
  
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        
        // write code here -- return the number of cells in the table
        return posts.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // write code here -- let's create our individual cells
        let cell = tableView.dequeueReusableCell(withIdentifier: "customcell", for: indexPath)
        
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.font = cell.textLabel?.font.withSize(30)
        cell.textLabel?.textColor = UIColor.init(red: 153/255.0, green: 0/255.0, blue: 200/255.0, alpha: 1)
        
        cell.textLabel?.text = posts[indexPath.item]
        
        return cell

    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ref = Database.database().reference().child("posts")
        
        posts = []
        
        ref.observeSingleEvent(of: DataEventType.value, with: { (snapshot)
            in
            
            for currentPost in snapshot.children.allObjects as!
                [DataSnapshot] {
                let post = currentPost.value as! String
                self.posts.append(post)
            }
            
            self.posts.reverse()
            self.newsfeed.reloadData()
            
        })

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
